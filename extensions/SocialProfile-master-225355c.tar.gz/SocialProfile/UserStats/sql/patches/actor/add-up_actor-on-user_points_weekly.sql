ALTER TABLE /*_*/user_points_weekly ADD COLUMN up_actor bigint unsigned NOT NULL AFTER up_id;
