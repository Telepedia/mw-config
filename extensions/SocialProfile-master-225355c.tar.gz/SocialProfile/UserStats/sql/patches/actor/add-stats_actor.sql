ALTER TABLE /*_*/user_stats ADD COLUMN stats_actor bigint unsigned NOT NULL FIRST;
