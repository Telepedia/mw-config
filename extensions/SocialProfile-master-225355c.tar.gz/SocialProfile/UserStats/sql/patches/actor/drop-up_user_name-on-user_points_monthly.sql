ALTER TABLE /*_*/user_points_monthly DROP COLUMN up_user_name;
