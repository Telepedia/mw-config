ALTER TABLE user_points_monthly ADD COLUMN up_actor INTEGER NOT NULL;
