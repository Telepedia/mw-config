ALTER TABLE user_points_archive ADD COLUMN up_actor INTEGER NOT NULL;
