ALTER TABLE /*_*/user_system_messages DROP COLUMN um_user_name;
