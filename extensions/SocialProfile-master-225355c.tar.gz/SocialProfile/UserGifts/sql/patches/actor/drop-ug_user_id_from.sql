ALTER TABLE /*_*/user_gift DROP COLUMN ug_user_id_from;
