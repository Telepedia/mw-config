CREATE INDEX /*i*/upm_actor ON /*_*/user_points_monthly (up_actor);
