ALTER TABLE user_points_weekly ADD COLUMN up_actor INTEGER NOT NULL;
