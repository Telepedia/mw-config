ALTER TABLE /*_*/user_points_archive ADD COLUMN up_actor bigint unsigned NOT NULL AFTER up_date;
