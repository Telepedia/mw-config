ALTER TABLE /*_*/user_system_messages ADD COLUMN um_actor INTEGER NOT NULL;
