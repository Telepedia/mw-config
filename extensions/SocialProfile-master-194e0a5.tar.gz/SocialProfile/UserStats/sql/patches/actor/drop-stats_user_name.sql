ALTER TABLE /*_*/user_stats DROP COLUMN stats_user_name;
