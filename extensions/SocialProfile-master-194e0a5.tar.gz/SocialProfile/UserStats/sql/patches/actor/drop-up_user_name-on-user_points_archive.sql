ALTER TABLE /*_*/user_points_archive DROP COLUMN up_user_name;
