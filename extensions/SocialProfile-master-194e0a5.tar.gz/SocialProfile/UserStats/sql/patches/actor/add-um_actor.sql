ALTER TABLE /*_*/user_system_messages ADD COLUMN um_actor bigint unsigned NOT NULL AFTER um_id;
