CREATE INDEX /*i*/upw_actor ON /*_*/user_points_weekly (up_actor);
