DROP INDEX /*i*/upa_up_user_id ON /*_*/user_points_archive;
