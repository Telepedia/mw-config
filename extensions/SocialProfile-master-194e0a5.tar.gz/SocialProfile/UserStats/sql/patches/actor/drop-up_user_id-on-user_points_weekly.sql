ALTER TABLE /*_*/user_points_weekly DROP COLUMN up_user_id;
