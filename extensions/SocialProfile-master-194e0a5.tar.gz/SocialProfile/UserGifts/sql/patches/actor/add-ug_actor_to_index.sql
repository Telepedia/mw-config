CREATE INDEX /*i*/ug_actor_to ON /*_*/user_gift (ug_actor_to);
