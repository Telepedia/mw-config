ALTER TABLE /*_*/user_gift ADD COLUMN ug_actor_to bigint unsigned NOT NULL AFTER ug_gift_id;
