ALTER TABLE /*_*/gift ADD COLUMN gift_creator_actor bigint unsigned NOT NULL AFTER gift_access;
