ALTER TABLE /*_*/user_board DROP COLUMN ub_user_id_from;
