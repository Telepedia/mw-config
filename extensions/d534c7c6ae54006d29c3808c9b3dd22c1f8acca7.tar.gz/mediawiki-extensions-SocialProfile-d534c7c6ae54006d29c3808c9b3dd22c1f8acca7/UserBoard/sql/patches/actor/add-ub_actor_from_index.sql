CREATE INDEX /*i*/ub_actor_from ON /*_*/user_board (ub_actor_from);
