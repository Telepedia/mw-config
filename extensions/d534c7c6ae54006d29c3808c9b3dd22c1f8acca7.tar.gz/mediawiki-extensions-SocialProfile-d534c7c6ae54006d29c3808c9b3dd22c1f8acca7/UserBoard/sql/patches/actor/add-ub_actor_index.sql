CREATE INDEX /*i*/ub_actor ON /*_*/user_board (ub_actor);
