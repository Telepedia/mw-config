ALTER TABLE user_system_gift ADD COLUMN sg_actor INTEGER NOT NULL;
