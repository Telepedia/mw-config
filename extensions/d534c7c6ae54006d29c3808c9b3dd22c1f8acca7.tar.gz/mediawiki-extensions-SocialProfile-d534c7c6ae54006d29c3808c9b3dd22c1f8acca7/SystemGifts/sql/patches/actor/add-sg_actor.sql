ALTER TABLE /*_*/user_system_gift ADD COLUMN sg_actor bigint unsigned NOT NULL AFTER sg_gift_id;
