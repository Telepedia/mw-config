ALTER TABLE /*_*/user_system_gift DROP COLUMN sg_user_id;
