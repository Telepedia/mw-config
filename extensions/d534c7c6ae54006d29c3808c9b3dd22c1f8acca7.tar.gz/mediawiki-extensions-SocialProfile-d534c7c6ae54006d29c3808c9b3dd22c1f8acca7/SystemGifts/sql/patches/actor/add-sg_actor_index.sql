CREATE INDEX /*i*/sg_actor ON /*_*/user_system_gift (sg_actor);
