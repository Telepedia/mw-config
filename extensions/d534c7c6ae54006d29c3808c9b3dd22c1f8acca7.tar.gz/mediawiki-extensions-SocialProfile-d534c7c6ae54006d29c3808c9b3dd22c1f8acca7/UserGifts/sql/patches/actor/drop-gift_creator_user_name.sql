ALTER TABLE /*_*/gift DROP COLUMN gift_creator_user_name;
