ALTER TABLE /*_*/user_gift DROP COLUMN ug_user_name_to;
