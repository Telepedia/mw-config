DROP INDEX /*i*/upm_up_user_id ON /*_*/user_points_monthly;
