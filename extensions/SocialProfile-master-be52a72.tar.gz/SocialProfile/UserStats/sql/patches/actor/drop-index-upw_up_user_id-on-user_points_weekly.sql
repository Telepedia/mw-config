DROP INDEX /*i*/upw_up_user_id ON /*_*/user_points_weekly;
