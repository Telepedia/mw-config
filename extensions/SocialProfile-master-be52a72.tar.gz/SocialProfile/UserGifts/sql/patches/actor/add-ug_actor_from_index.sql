CREATE INDEX /*i*/ug_actor_from ON /*_*/user_gift (ug_actor_from);
