ALTER TABLE /*_*/user_gift ADD COLUMN ug_actor_from bigint unsigned NOT NULL AFTER ug_actor_to;
