ALTER TABLE /*_*/oathauth_users
	DROP COLUMN secret,
	DROP COLUMN scratch_tokens;
