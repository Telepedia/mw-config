ALTER TABLE /*_*/oathauth_users
	ADD module VARCHAR( 255 ) NOT NULL,
	ADD data BLOB NULL;
