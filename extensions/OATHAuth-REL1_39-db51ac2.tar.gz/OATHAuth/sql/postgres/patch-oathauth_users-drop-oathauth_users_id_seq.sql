DROP SEQUENCE IF EXISTS oathauth_users_id_seq CASCADE;
