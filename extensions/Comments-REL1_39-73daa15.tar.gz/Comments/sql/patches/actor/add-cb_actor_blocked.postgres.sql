ALTER TABLE "Comments_block" ADD COLUMN cb_actor_blocked INTEGER NOT NULL;
