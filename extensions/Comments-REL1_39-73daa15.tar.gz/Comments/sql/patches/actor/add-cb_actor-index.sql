CREATE INDEX /*i*/cb_actor ON /*_*/Comments_block (cb_actor);
