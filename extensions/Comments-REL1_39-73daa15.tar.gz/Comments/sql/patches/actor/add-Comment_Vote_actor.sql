ALTER TABLE /*_*/Comments_Vote ADD COLUMN Comment_Vote_actor bigint unsigned NOT NULL AFTER Comment_Vote_ID;
