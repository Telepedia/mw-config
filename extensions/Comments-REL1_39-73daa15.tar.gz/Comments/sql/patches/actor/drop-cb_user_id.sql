ALTER TABLE /*_*/Comments_block DROP COLUMN cb_user_id;
