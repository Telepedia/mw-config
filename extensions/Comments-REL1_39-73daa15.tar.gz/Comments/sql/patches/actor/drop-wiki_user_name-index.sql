DROP INDEX /*i*/wiki_user_name ON /*_*/Comments;
