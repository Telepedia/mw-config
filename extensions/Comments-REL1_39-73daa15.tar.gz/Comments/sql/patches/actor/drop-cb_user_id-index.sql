DROP INDEX /*i*/cb_user_id ON /*_*/Comments_block;
