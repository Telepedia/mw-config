ALTER TABLE "Comments_Vote" ADD COLUMN Comment_Vote_actor INTEGER NOT NULL;
