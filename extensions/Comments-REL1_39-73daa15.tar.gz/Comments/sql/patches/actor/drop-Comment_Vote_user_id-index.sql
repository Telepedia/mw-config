DROP INDEX /*i*/Comment_Vote_user_id ON /*_*/Comments_Vote;
