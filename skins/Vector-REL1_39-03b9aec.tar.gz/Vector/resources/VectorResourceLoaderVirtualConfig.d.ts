/** See Vector\Hooks::getVectorResourceLoaderConfig */
interface VectorResourceLoaderVirtualConfig {
	wgVectorSearchHost: string;
}
