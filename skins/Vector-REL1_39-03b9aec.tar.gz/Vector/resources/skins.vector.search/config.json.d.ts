// Placeholder for ResourceLoader Virtual Config which is populated from the server.
// See `VectorWvuiSearchOptions` config in Vector/skin.json for the options that are included.
export {};
